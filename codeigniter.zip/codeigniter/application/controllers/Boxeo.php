<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';

class Boxeo extends REST_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('boxeo_model');
	}

	public function index_get()
	{
		$index = $this->boxeo_model->get();
		$this->response(array('response' => $index));
	}

	public function find_get($id)
	{
		$find = $this->boxeo_model->get($id);
		$this->response(array('response' => $find));
	}

	public function index_post()
	{
		$id = $this->boxeo_model->guardar($this->post('find'));
		$this->response(array('response' => $id));
	}

	public function index_put($id)
	{
		$update = $this->boxeo_model->update($id, $this->post('find'));
		$this->response(array('response' => $update));
	}

	public function index_delete($id)
	{
		$delete = $this->boxeo_model->delete($id);
		$this->response(array('response' => $delete));
	}
}

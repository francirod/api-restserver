<?php
class Boxeo_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
	}

	public function get($id = null)
	{
		if (!is_null($id))
		{
			$query = $this->db->select('*')->from('boxeo')->where('id', $id)->get();
			if ($query->num_rows() === 1)
			{
				return $query->row_array();
			}
		return false;
		}

		$query = $this->db->select('*')->from('boxeo')->get();
		if ($query->num_rows() > 0)
		{
			return $query->result_array();
		}
		return false;
	}

	public function guardar($find)
	{
		$this->db->set($this->_setpalabra($find))->insert('boxeo');
		if ($this->db->affected_rows() === 1)
		{
			return $this->db->insert_id();
		}
		return false;
}

	public function update($id, $find)
	{
		$this->db->set($this->_setpalabra($find))->where('id', $id)->update('palabra');
                if ($this->db->affected_rows() === 1)
                {
                        return true;
                }
                return false;

	}

	public function delete($id)
	{
		$this->db->where('id', $id)->delete('boxeo');
		if ($this->db->affected_rows() === 1)
		{
			return true;
		}
		return false;
	}

	private function _setpalabra($find)
	{
		return array(
			"id" 		=> $find["id"],
			"nombre" 	=> $find["nombre"],
			"descripcion"	=> $find["descripcion"]
		);
	}
}

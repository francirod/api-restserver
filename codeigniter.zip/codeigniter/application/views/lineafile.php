<p> <?php echo $linea?> </p>
